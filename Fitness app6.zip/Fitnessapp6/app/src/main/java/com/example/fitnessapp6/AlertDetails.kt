package com.example.fitnessapp6


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class AlertDetails : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alert_details)

        // Additional initialization or setup code can be added here
    }
}